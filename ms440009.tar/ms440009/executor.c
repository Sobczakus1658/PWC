#include "err.h"
#include "utils.h"

#include <sys/mman.h>
#include <signal.h>
#include <fcntl.h> 
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h> 
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>


#define MAX_SIZE_INPUT  511
#define MAX_SIZE_OUTPUT  1022
#define MAX_N_TASKS  4096

struct Task {
    pid_t pid_task;
    int pipe_dsc_out;
    int pipe_dsc_err;
    char lastout[MAX_SIZE_INPUT];
    char lasterr[MAX_SIZE_INPUT];
    sem_t semaphore_out;
    sem_t semaphore_err;
    bool send; 
};

int *task_counter;
sem_t *mutex;

struct Task *tasks;

struct Queue{
    sem_t mutex;
    int last_position;
    char* messages[MAX_N_TASKS];
};
struct Queue *queue;

void convert(char * task, int a, int length){
    task[length] = '\0';
    int copy = a ;
    int last_index = length - 1;
    if(copy == 0){
        task[0] = '0';
        task[1] = '\0';
        return;
    }
    while(copy != 0) {
        task[last_index] = copy%10 + '0';
        copy = copy / 10;
        last_index --;
    }
}
void handler(int sig, siginfo_t* info, void* more){
    ASSERT_SYS_OK(sem_wait(mutex));
    int tasks_number = *task_counter;
    ASSERT_SYS_OK(sem_post(mutex));
    pid_t pid = info->si_pid;
    int i = 0;
    while(tasks[i].pid_task != pid && i < tasks_number){
        i++;
    }
    if( i == tasks_number){
        return;
    }
    else{
        char str[60] = "Task ";
        int copy = i;
        int length = 0;
        if(copy == 0){
            length = 1; 
        }
        while(copy != 0){
            length++;
            copy = copy/10;
        }
        char task[length + 1];
        convert(task, i, length);
        strcat(str, task);
        strcat(str, " ended: ");
        if (info->si_code == CLD_EXITED) {
            char status[12] = "status ";
            strcat(str, status);
            int number_status = info->si_status;
            int copy = number_status;
            int length = 0;
            if(copy == 0){
                length = 1; 
            }
            while(copy != 0){
                length++;
                copy = copy/10;
            }
            char number[length + 1];
            convert(number, number_status, length);
            strcat(str,number);
            strcat(str, ".\n");
        }
        else{
            char signalled[12] = "signalled.\n";
            strcat(str, signalled);
        }
        tasks[i].send = true;
        ASSERT_SYS_OK(sem_wait(&queue->mutex));
        strcpy(queue->messages[queue->last_position], str);
        queue->last_position = queue->last_position + 1;
        ASSERT_SYS_OK(sem_post(&queue->mutex));
    }
}

void kill_task(char** instruction)
{
    int number;
    sscanf(instruction[1], "%d", &number);
    kill(tasks[number].pid_task, SIGINT);
}

void out(char** instruction)
{
    int number = atoi(instruction[1]);
    ASSERT_SYS_OK(sem_wait(&tasks[number].semaphore_out));
    char str[MAX_SIZE_INPUT] = "Task ";
    strcat(str,instruction[1]);
    strcat(str, " stdout: \'");
    if( tasks[number].lastout[strlen(tasks[number].lastout) - 1] == '\n'){
        tasks[number].lastout[strlen(tasks[number].lastout) - 1] = '\0';
    }
    strcat(str, tasks[number].lastout);
    strcat(str, "\'.\n");
    write(STDOUT_FILENO, str, strlen(str));
    ASSERT_SYS_OK(sem_post(&tasks[number].semaphore_out));
}

void err(char** instruction)
{
    int number = atoi(instruction[1]);
    ASSERT_SYS_OK(sem_wait(&tasks[number].semaphore_err));
    char str[MAX_SIZE_INPUT] = "Task ";
    strcat(str, instruction[1]);
    strcat(str, " stderr: \'");
        if( tasks[number].lasterr[strlen(tasks[number].lasterr) - 1] == '\n'){
        tasks[number].lasterr[strlen(tasks[number].lasterr) - 1] = '\0';
    }
    strcat(str,tasks[number].lasterr);
    strcat(str, "\'.\n");
    write(STDOUT_FILENO, str, strlen(str) );
    ASSERT_SYS_OK(sem_post(&tasks[number].semaphore_err));
}

void run(char** instruction)
{   ASSERT_SYS_OK(sem_wait(mutex));
    int actually_task = *task_counter;
    ASSERT_SYS_OK(sem_post(mutex));
    int prot = PROT_READ | PROT_WRITE;
    int flags = MAP_SHARED | MAP_ANONYMOUS;
    sem_t* sem = mmap( NULL, sizeof(sem_t), prot,
                    flags, -1, 0);
    if(sem == MAP_FAILED){
        syserr("nmap error");
    }

    ASSERT_SYS_OK(sem_init(&tasks[actually_task].semaphore_out, 1 ,1));
    ASSERT_SYS_OK(sem_init(sem, 1, 0));
    ASSERT_SYS_OK(sem_init(&tasks[actually_task].semaphore_err, 1 ,1));

    pid_t pid = fork();
    ASSERT_SYS_OK(pid);

    if (!pid) {

        int pipe_dsc_out[2];
        int pipe_dsc_err[2];
        int pipe_dsc_in[2];
        ASSERT_SYS_OK(pipe(pipe_dsc_in));
        ASSERT_SYS_OK(close(pipe_dsc_in[1]));
        ASSERT_SYS_OK(dup2(pipe_dsc_in[0], STDIN_FILENO));
        ASSERT_SYS_OK(close(pipe_dsc_in[0]));

        ASSERT_SYS_OK(pipe(pipe_dsc_out));
        ASSERT_SYS_OK(pipe(pipe_dsc_err));
        pid_t pid = fork();
        ASSERT_SYS_OK(pid);
        
        if(!pid){
            ASSERT_SYS_OK(close(pipe_dsc_err[0]));
            ASSERT_SYS_OK(close(pipe_dsc_out[0]));

            ASSERT_SYS_OK(dup2(pipe_dsc_out[1], STDOUT_FILENO));
            ASSERT_SYS_OK(close(pipe_dsc_out[1]));
            ASSERT_SYS_OK(dup2(pipe_dsc_err[1], STDERR_FILENO));
            ASSERT_SYS_OK(close(pipe_dsc_err[1]));

            char* program_name = instruction[1];
            char** arguments = &instruction[1];
            tasks[actually_task].pid_task = getpid();
            ASSERT_SYS_OK(sem_post(sem));
            for(int i = 0; i < MAX_SIZE_INPUT; i++){
                ASSERT_SYS_OK(munmap(queue->messages[i], 160));
            }  
            ASSERT_SYS_OK(munmap(tasks, sizeof(struct Task) * MAX_N_TASKS));
            ASSERT_SYS_OK(munmap(task_counter, sizeof(int)));
            ASSERT_SYS_OK(munmap(queue, sizeof(struct Queue)));
            ASSERT_SYS_OK(munmap(mutex,sizeof(sem_t)));
            ASSERT_SYS_OK(munmap(sem,sizeof(sem_t)));
            execvp(program_name, arguments);
        }
        else{
            free_split_string(instruction);
            ASSERT_SYS_OK(close(pipe_dsc_err[1]));
            ASSERT_SYS_OK(close(pipe_dsc_out[1]));

            pid_t pid = fork();
            ASSERT_SYS_OK(pid);
            if(!pid){
                ASSERT_SYS_OK(close(pipe_dsc_err[0]));
                int success = true;
                FILE * file;
                file = fdopen(pipe_dsc_out[0],"r");
                char buf[MAX_SIZE_INPUT];
                while (success) {            
                    success = read_line(buf, MAX_SIZE_INPUT, file);
                    ASSERT_SYS_OK(sem_wait(&tasks[actually_task].semaphore_out));
                    if(success){
                        strcpy(tasks[actually_task].lastout, buf);
                    }
                    ASSERT_SYS_OK(sem_post(&tasks[actually_task].semaphore_out));
                }
                fclose(file);
                for(int i = 0; i < MAX_SIZE_INPUT; i++){
                    ASSERT_SYS_OK(munmap(queue->messages[i], 160));
                }  
                ASSERT_SYS_OK(munmap(tasks, sizeof(struct Task) * MAX_N_TASKS));
                ASSERT_SYS_OK(munmap(task_counter, sizeof(int)));
                ASSERT_SYS_OK(munmap(queue, sizeof(struct Queue)));
                ASSERT_SYS_OK(munmap(mutex,sizeof(sem_t)));
                ASSERT_SYS_OK(munmap(sem,sizeof(sem_t)));
                exit(0);
            }
            
            sigset_t block_mask;
            sigemptyset(&block_mask);
            ASSERT_SYS_OK(sigaddset(&block_mask, SIGCHLD));
               
            ASSERT_SYS_OK(close(pipe_dsc_out[0]));
            int success = true;
            FILE * file;
            file = fdopen(pipe_dsc_err[0],"r");
            char buf[MAX_SIZE_INPUT];
            while (success) {
               // ASSERT_SYS_OK(sigprocmask(SIG_BLOCK, &block_mask, NULL));
                success = read_line(buf, MAX_SIZE_INPUT, file);
              //  ASSERT_SYS_OK(sigprocmask(SIG_UNBLOCK, &block_mask, NULL));
                ASSERT_SYS_OK(sem_wait(&tasks[actually_task].semaphore_err));
                if(success){
                    strcpy(tasks[actually_task].lasterr, buf);
                }
                ASSERT_SYS_OK(sem_post(&tasks[actually_task].semaphore_err));
            }
            fclose(file);
            //ASSERT_SYS_OK(sigprocmask(SIG_BLOCK, &block_mask, NULL));
            ASSERT_SYS_OK(waitpid(pid, NULL, 0));
            //ASSERT_SYS_OK(sigprocmask(SIG_UNBLOCK, &block_mask, NULL));
        
            int wstatus;
            waitpid(tasks[actually_task].pid_task,&wstatus,0);
            if(!tasks[actually_task].send){
                char str[MAX_SIZE_INPUT] = "Task ";
                int copy = actually_task;
                int length = 0;
                if(copy == 0){
                length = 1; 
                }
                while(copy != 0){
                    length++;
                    copy = copy/10;
                }
                char task[length +1];
                convert(task, actually_task, length);
                strcat(str, task);
                strcat(str, " ended: ");
                if (WIFEXITED(wstatus)) {
                    char status[12] = "status ";
                    strcat(str, status);
                    int number_status = WEXITSTATUS(wstatus);
                    int copy = number_status;
                    int length = 0;
                    if(copy == 0){
                        length = 1; 
                    }
                    while(copy != 0){
                        length++;
                        copy = copy/10;
                    }
                    char number[length + 1];
                    convert(number, number_status, length);
                    strcat(str,number);
                    strcat(str, ".\n");
                }
                else{
                    char signalled[12] = "signalled.\n";
                    strcat(str, signalled);
                }
                ASSERT_SYS_OK(sem_wait(&queue->mutex));
                strcpy(queue->messages[queue->last_position], str);
                queue->last_position = queue->last_position + 1;
                ASSERT_SYS_OK(sem_post(&queue->mutex));
            }
            for(int i = 0; i < MAX_SIZE_INPUT; i++){
                ASSERT_SYS_OK(munmap(queue->messages[i], 160));
            }  
            ASSERT_SYS_OK(munmap(tasks, sizeof(struct Task) * MAX_N_TASKS));
            ASSERT_SYS_OK(munmap(task_counter, sizeof(int)));
            ASSERT_SYS_OK(munmap(queue, sizeof(struct Queue)));
            ASSERT_SYS_OK(munmap(mutex,sizeof(sem_t)));
            ASSERT_SYS_OK(munmap(sem,sizeof(sem_t)));
            exit(0);
        }      
    }
    else{
        ASSERT_SYS_OK(sem_wait(sem));
        ASSERT_SYS_OK(sem_destroy(sem));
        ASSERT_SYS_OK(munmap(sem,sizeof(sem_t)));
        char str_out[MAX_SIZE_INPUT] = "Task ";
        int copy = actually_task;
        int length = 0;
        if(copy == 0){
            length = 1; 
        }
        while(copy != 0){
            length++;
            copy = copy/10;
        }
        char task[length + 1];
        convert(task, actually_task, length);
        strcat(str_out, task);
        strcat(str_out, " started: pid ");
        copy = tasks[actually_task].pid_task;
        length = 0;
        if(copy == 0){
            length = 1; 
        }
        while(copy != 0){
            length++;
            copy = copy/10;
        }
        char pid[length + 1];
        convert(pid, tasks[actually_task].pid_task, length);
        strcat(str_out, pid);
        strcat(str_out, ".\n");
        write(STDOUT_FILENO, str_out, strlen(str_out));
        ASSERT_SYS_OK(sem_wait(mutex));
        *task_counter += 1;
        ASSERT_SYS_OK(sem_post(mutex));
    }
}

void sleep_program(char** instruction)
{
    int number;
    sscanf(instruction[1], "%d", &number);
    usleep(1000* number);
}

void quit()
{   
    for (int i = 0; i < *task_counter; i++) {
        if (tasks[i].pid_task != 0) {
            kill(tasks[i].pid_task, SIGQUIT);
        }
    }
}

void reader()
{  
    bool correct_input = true;
    char line[MAX_SIZE_INPUT];
    sigset_t block_mask;
    sigemptyset(&block_mask);
    ASSERT_SYS_OK(sigaddset(&block_mask, SIGCHLD));
    while (correct_input) {
        ASSERT_SYS_OK(sigprocmask(SIG_BLOCK,&block_mask, NULL));
        correct_input = read_line(line, MAX_SIZE_INPUT, stdin);
        if(!correct_input){
            quit();
            break;
        }
        line[strlen(line) - 1] = '\0';
        char** program = split_string(line);
        if (strcmp(program[0], "run") == 0) {
            run(program);
        }
        if (strcmp(program[0], "kill") == 0) {
            kill_task(program);
        }
        if (strcmp(program[0], "out") == 0) {
            out(program);
        }
        if (strcmp(program[0], "err") == 0) {
            err(program);
        }
        if (strcmp(program[0], "sleep") == 0) {
            sleep_program(program);
        }
        if (strcmp(program[0], "quit") == 0) {
            quit();
            free_split_string(program);
            break;
        } 
        ASSERT_SYS_OK(sem_wait(&queue->mutex));
        int i = 0;
        while(i < queue->last_position){
            write(STDOUT_FILENO, queue->messages[i], strlen(queue->messages[i]));
            i++;
        }
        queue->last_position = 0;
        ASSERT_SYS_OK(sem_post(&queue->mutex));
        free_split_string(program);
        ASSERT_SYS_OK(sigprocmask(SIG_UNBLOCK,&block_mask, NULL));
    }
}
int main()
{   
    tasks = mmap(
    NULL,
    sizeof(struct Task) * MAX_N_TASKS,
    PROT_READ | PROT_WRITE,
    MAP_SHARED | MAP_ANONYMOUS,
    -1,0);

    task_counter = mmap(
    NULL,
    sizeof(int),
    PROT_READ | PROT_WRITE,
    MAP_SHARED | MAP_ANONYMOUS,
    -1,0
    );

    queue = mmap(
    NULL, 
    sizeof(struct Queue),
    PROT_READ | PROT_WRITE,
    MAP_SHARED | MAP_ANONYMOUS,
    -1,0
    );
    if(queue == MAP_FAILED){
        syserr("mmap");
    }
    mutex = mmap(
        NULL,
        sizeof(sem_t),
        PROT_READ | PROT_WRITE,
        MAP_SHARED | MAP_ANONYMOUS,
        -1,0
    );
    if(mutex == MAP_FAILED){
        syserr("mmap");
    }

    queue->last_position = 0;  
    for(int i = 0; i < MAX_SIZE_INPUT; i++){
        queue->messages[i] = mmap(
            NULL,
            160,
            PROT_READ | PROT_WRITE,
            MAP_SHARED | MAP_ANONYMOUS,
            -1, 0);
        if(queue->messages[i] == MAP_FAILED){
            syserr("mmap");
        }
    }  
    ASSERT_SYS_OK(sem_init(mutex, 1, 1));
    ASSERT_SYS_OK(sem_init(&queue->mutex, 1 ,1));
    *task_counter = 0;

       
    struct sigaction action;
    sigemptyset(&action.sa_mask);
    action.sa_sigaction = handler;
    action.sa_flags = SA_SIGINFO;
    ASSERT_SYS_OK(sigaction(SIGCHLD, &action, NULL));

    reader();
    ASSERT_SYS_OK(sem_wait(mutex));
    int number_of_tasks = *task_counter;
    ASSERT_SYS_OK(sem_post(mutex));
    for(int i = 0; i < number_of_tasks; i++){
        kill(tasks[i].pid_task,SIGKILL);
        ASSERT_SYS_OK(wait(NULL));
        ASSERT_SYS_OK(sem_destroy(&tasks[i].semaphore_err));
        ASSERT_SYS_OK(sem_destroy(&tasks[i].semaphore_out));
    }
   
    int i = 0;
    while(i < queue->last_position){
        write(STDOUT_FILENO, queue->messages[i], strlen(queue->messages[i]));
        i++;
    }
    queue->last_position = 0;

    for(int i = 0; i < MAX_SIZE_INPUT; i++){
        ASSERT_SYS_OK(munmap(queue->messages[i], 160));
    }  
    ASSERT_SYS_OK(munmap(tasks, sizeof(struct Task) * MAX_N_TASKS));
    ASSERT_SYS_OK(munmap(task_counter, sizeof(int)));
    ASSERT_SYS_OK(munmap(queue, sizeof(struct Queue)));
    ASSERT_SYS_OK(sem_destroy(&queue->mutex));
    ASSERT_SYS_OK(sem_destroy(mutex));
    ASSERT_SYS_OK(munmap(mutex,sizeof(sem_t)));
}
